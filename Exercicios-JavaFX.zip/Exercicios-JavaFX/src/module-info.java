module exerciciosFX {
	
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;		
	
	opens Basico;
	opens Layout;
	opens fxml;
}