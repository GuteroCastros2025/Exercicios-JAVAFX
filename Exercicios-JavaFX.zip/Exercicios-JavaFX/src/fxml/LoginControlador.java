package fxml;

public class LoginControlador {

	public void entrar() {
		System.out.println("entrar......");
	}
}
